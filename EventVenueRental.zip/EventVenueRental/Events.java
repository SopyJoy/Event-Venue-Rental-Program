

public class Events
{
    public String name, venueName, contactNum, serviceName;
    public int price, guests;
    
    public Events(){}
    
    public void setName(String name)
    {
        this.name = name;    
    }
    
    public void setVenueName(String venueName)
    {
        this.venueName = venueName;    
    }
    
    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;    
    }
    
    public void setContactNum(String contactNum)
    {
        this.contactNum = contactNum;    
    }
    
    public void setPrice(int price)
    {
        this.price = price;    
    }
    
    public void setGuests(int guests)
    {
        this.guests = guests;    
    }
    
    public String getName()
    {
        return name;        
    }
    
    public String getVenueName()
    {
        return venueName;        
    }
    
    public String getServiceName()
    {
        return serviceName;        
    }
    
    public String getContactNum()
    {
        return contactNum;        
    }

    public int getPrice()
    {
        return price;        
    }

    public int getGuests()
    {
        return guests;        
    }
    
    public Events(String name, String venueName, String serviceName, int price, int guests)
    {    
        this.name = name;
        this.venueName = venueName;
        this.serviceName = serviceName;
        this.price = price;
        this.guests = guests;
    }
    
}

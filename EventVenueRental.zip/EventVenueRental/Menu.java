import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Menu extends JFrame
{
    
    public Menu()
    {
        
        //for closing the window
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
            exitForm(e);
        }
        });
        
        //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-230,-160,500,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(40,-160,500,350);
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(210,-160,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(290,-160,500,350);
        
        //Menu option Text
        JLabel menuText = new JLabel("MENU");
        menuText.setFont(new Font("Arial", 1, 60));
        menuText.setForeground(new Color(255,255,255));
        menuText.setBounds(160,-70,200,300);
        
        //Venue Button
        JButton venueButton = new JButton("EVENT VENUES");
        venueButton.setFont(new Font("Arial", 1, 16));
        venueButton.setForeground(new Color(255,255,255));
        venueButton.setBackground(new Color(0,0,0));
        venueButton.setBounds(150,130,200,40);//taas y for other buttons
        
        //package Button
        JButton packageButton = new JButton("PACKAGES");
        packageButton.setFont(new Font("Arial", 1, 16));
        packageButton.setForeground(new Color(255,255,255));
        packageButton.setBackground(new Color(0,0,0));
        packageButton.setBounds(150,180,200,40);
        
        //service Button
        JButton serviceButton = new JButton("SERVICES");
        serviceButton.setFont(new Font("Arial", 1, 16));
        serviceButton.setForeground(new Color(255,255,255));
        serviceButton.setBackground(new Color(0,0,0));
        serviceButton.setBounds(150,230,200,40);
        
        //Booking Button
        JButton bookingButton = new JButton("BOOKING");
        bookingButton.setFont(new Font("Arial", 1, 16));
        bookingButton.setForeground(new Color(255,255,255));
        bookingButton.setBackground(new Color(0,0,0));
        bookingButton.setBounds(150,280,200,40);
        
        //main Button
        JButton mainButton = new JButton("Back to Main");
        mainButton.setFont(new Font("Arial", 0, 14));
        mainButton.setForeground(new Color(255,255,255));
        mainButton.setBackground(new Color(0,0,0));
        mainButton.setBounds(175,360,150,25);
        
        //exit Button
        JButton exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Arial", 0, 14));
        exitButton.setForeground(new Color(255,255,255));
        exitButton.setBackground(new Color(0,0,0));
        exitButton.setBounds(175,390,150,25);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(10,415,500,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(165,265,500,350);
    
        //Credits background below
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,425,500,40);
        
        //background
        ImageIcon imageB = new ImageIcon(getClass().getResource("Menu Background.png"));
        JLabel background = new JLabel(imageB);
        background.setBounds(0,30,500,400);
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(500,500);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        //Added to the Pane
        add(pictureLogo);
        add(logoText);
        add(philLogo);
        add(location);
        add(menuText);
        add(venueButton);
        add(packageButton);
        add(serviceButton);
        add(bookingButton);
        add(mainButton);
        add(exitButton);
        add(membersName);
        add(socMedPics);
        add(backgroundBelow);
        add(background);
        
        //Events
         //for start button action event
        venueButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            venueButtonActionPerformed(e);
        }
        });
        
        packageButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            packageButtonActionPerformed(e);
        }
        });
        
        serviceButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            serviceButtonActionPerformed(e);
        }
        });
        
        bookingButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            bookingButtonActionPerformed(e);
        }
        });
        
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            exitButtonActionPerformed(e);
        
        }
        });
        
        mainButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            mainButtonActionPerformed(e);
        
        }
        });
        
        
    }
        
    private void exitForm(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you for using this Application");
        System.exit(0);
    }
    
    private void venueButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        new venueWindow().show();
        this.dispose();
    }
    
    private void packageButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        new packageWindow().show();
        this.dispose();
    }
    
    private void bookingButtonActionPerformed(ActionEvent e){
        JFrame booking;
        booking = new JFrame();
        new bookWindow().show();
        this.dispose();
    }
    
    private void serviceButtonActionPerformed(ActionEvent e){
        JFrame service;
        service = new JFrame();
        new serviceWindow().show();
        this.dispose();
    }
    
    private void exitButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you for using this Application!");
        System.exit(0);
    }
    
    private void mainButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        new LandingPage().show();
        this.dispose();
    }
    
    public static void main(String[] args){
        new Menu().show();
    }
}



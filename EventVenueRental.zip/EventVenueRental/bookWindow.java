import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class bookWindow extends JFrame
{
    JTextField nameTextField = new JTextField();
    JTextField contactNumTextField = new JTextField();
    JTextField venueNameTextField = new JTextField();
    JTextField packageNameTextField = new JTextField();
    JTextField serviceNameTextField = new JTextField();
    JTextField guestsTextField = new JTextField();
    JTextField priceTextField = new JTextField();
   
    JLabel venuePriceLabel = new JLabel();
    JLabel packagePriceLabel = new JLabel();
    JLabel servicePriceLabel = new JLabel();
    JLabel priceLabel = new JLabel();
    
    //gets name variable from the previous updated text field from CopyOfbookWindow
    public static String name = bookWindow.name;
    
    //gets contactNum variable from the previous updated text field from CopyOfbookWindow
    public static String contactNum = bookWindow.contactNum;
    
    //gets variables from venueWindow
    String VenueInfo = venueWindow.clickVenueInfo;
    int price = venueWindow.price;
    int pax = venueWindow.pax;
    
    //gets the variables from packageWindow
    String packageInfo = packageWindow.packageInfo;
    int packagePrice = packageWindow.packagePrice;
    
    //gets variables from serviceWindow
    String serviceInfo = serviceWindow.serviceInfo;
    int servicePrice = serviceWindow.servicePrice;
    
    int totalPrice = price + packagePrice + servicePrice;
    
    //creates Events Object
    Events event = new Events();
    Packages packages = new Packages();
    
    public bookWindow()
    {
        //sets the attributes of the Event Object
        event.setName(name);
        event.setContactNum(contactNum);
        event.setVenueName(VenueInfo);
        packages.setPackageName(packageInfo);
        event.setServiceName(serviceInfo);
        event.setGuests(pax);
        event.setPrice(totalPrice);
        
         //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-220,-155,500,350);//x=columns y=rows width, height
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(700,-155,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(780,-155,700,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(50,-155,500,350);
        
        //banner
        ImageIcon imageB = new ImageIcon(getClass().getResource("Booking Banner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(-5,-275,1005,800);
        
        //text after the banner
        JLabel instructLabel = new JLabel("Fill in the Following Information");
        instructLabel.setFont(new Font("Arial", 1, 25));
        instructLabel.setForeground(new Color(0,0,0));
        instructLabel.setBounds(320,190,800,100);
        
        //name Text
        JLabel nameLabel = new JLabel("Full Name: ");
        nameLabel.setFont(new Font("Arial", 0, 18));
        nameLabel.setForeground(new Color(0, 0,0));
        nameLabel.setBounds(70,270,1000,50);
        
        //name TextField
        nameTextField.setText(event.getName());
        nameTextField.setFont(new Font("Arial", 0, 18));
        nameTextField.setBackground(new Color(204,204,204));
        nameTextField.setForeground(new Color(0, 0,0));
        nameTextField.setBounds(230,283,250,25);
        
        //Contact Text
        JLabel contactNumLabel = new JLabel("Contact Number: ");
        contactNumLabel.setFont(new Font("Arial", 0, 18));
        contactNumLabel.setForeground(new Color(0, 0,0));
        contactNumLabel.setBounds(70,303,1000,50);
        
        //Contact TextField
        contactNumTextField.setText(event.getContactNum());
        contactNumTextField.setFont(new Font("Arial", 0, 18));
        contactNumTextField.setBackground(new Color(204,204,204));
        contactNumTextField.setForeground(new Color(0, 0,0));
        contactNumTextField.setBounds(230,315,250,25);
       
        //Venue Text
        JLabel venueNameLabel = new JLabel("Venue Name: ");
        venueNameLabel.setFont(new Font("Arial", 0, 18));
        venueNameLabel.setForeground(new Color(0, 0,0));
        venueNameLabel.setBounds(70,337,1000,50);
        
        //Venue TextField
        venueNameTextField.setText(event.getVenueName());
        venueNameTextField.setFont(new Font("Arial", 0, 18));
        venueNameTextField.setBackground(new Color(204,204,204));
        venueNameTextField.setForeground(new Color(0, 0,0));
        venueNameTextField.setBounds(230,348,250,25);
        venueNameTextField.setEditable(false);
        
        //Package Text
        JLabel packageNameLabel = new JLabel("Package Name: ");
        packageNameLabel.setFont(new Font("Arial", 0, 18));
        packageNameLabel.setForeground(new Color(0, 0,0));
        packageNameLabel.setBounds(70,373,1000,50);
        
        //Package TextField
        packageNameTextField.setText(packages.getPackageName());
        packageNameTextField.setFont(new Font("Arial", 0, 18));
        packageNameTextField.setBackground(new Color(204,204,204));
        packageNameTextField.setForeground(new Color(0, 0,0));
        packageNameTextField.setBounds(230,383,250,25);
        packageNameTextField.setEditable(false);
        
        //Service Text
        JLabel serviceNameLabel = new JLabel("Service: ");
        serviceNameLabel.setFont(new Font("Arial", 0, 18));
        serviceNameLabel.setForeground(new Color(0, 0,0));
        serviceNameLabel.setBounds(70,408,1000,50);
        
        //Service Textfield
        serviceNameTextField.setText(event.getServiceName());
        serviceNameTextField.setFont(new Font("Arial", 0, 18));
        serviceNameTextField.setBackground(new Color(204,204,204));
        serviceNameTextField.setForeground(new Color(0, 0,0));
        serviceNameTextField.setBounds(230,418,250,25);
        serviceNameTextField.setEditable(false);
        
        //Guest Text
        JLabel guestsLabel = new JLabel("Total Guest: ");
        guestsLabel.setFont(new Font("Arial", 0, 18));
        guestsLabel.setForeground(new Color(0, 0,0));
        guestsLabel.setBounds(70,445,1000,50);
        
        //Guest TextField
        guestsTextField.setText(String.valueOf(event.getGuests()));
        guestsTextField.setFont(new Font("Arial", 0, 18));
        guestsTextField.setBackground(new Color(204,204,204));
        guestsTextField.setForeground(new Color(0, 0,0));
        guestsTextField.setBounds(230,453,250,25);
        guestsTextField.setEditable(false);
        
        //Price Text
        JLabel priceLabel = new JLabel("Total Price: ");
        priceLabel.setFont(new Font("Arial", 0, 18));
        priceLabel.setForeground(new Color(0, 0,0));
        priceLabel.setBounds(70,480,1000,50);
        
        //Price TextField
        priceTextField.setText(String.valueOf(event.getPrice()));
        priceTextField.setFont(new Font("Arial", 0, 18));
        priceTextField.setBackground(new Color(204,204,204));
        priceTextField.setForeground(new Color(0, 0,0));
        priceTextField.setBounds(230,490,250,25);
        priceTextField.setEditable(false);
        
        //Breakdown Text
        JLabel breakdownLabel = new JLabel("Breakdown of Fees");
        breakdownLabel.setFont(new Font("Arial", 1, 18));
        breakdownLabel.setForeground(new Color(0, 0,0));
        breakdownLabel.setBounds(600,270,200,50);
        
        //Venue Price Text
        venuePriceLabel.setText("Venue Fee: " + String.valueOf(price));
        venuePriceLabel.setFont(new Font("Arial", 0, 18));
        venuePriceLabel.setForeground(new Color(0, 0,0));
        venuePriceLabel.setBounds(600,310,500,50);
        
        //package price Text
        packagePriceLabel.setText("Package Fee: " + String.valueOf(packagePrice));
        packagePriceLabel.setFont(new Font("Arial", 0, 18));
        packagePriceLabel.setForeground(new Color(0, 0,0));
        packagePriceLabel.setBounds(600,340,500,50);
        
        //Service Price Label
        servicePriceLabel.setText("Service Fee: " + String.valueOf(servicePrice));
        servicePriceLabel.setFont(new Font("Arial", 0, 18));
        servicePriceLabel.setForeground(new Color(0, 0,0));
        servicePriceLabel.setBounds(600,370,500,50);
        
        //Venue Button
        JButton venueButton = new JButton("See Venues");
        venueButton.setFont(new Font("Arial", 0, 16));
        venueButton.setForeground(new Color(255,255,255));
        venueButton.setBackground(new Color(0,0,0));
        venueButton.setBounds(65,560,200,40);
        
        //package Button
        JButton packageButton = new JButton("See Packages");
        packageButton.setFont(new Font("Arial", 0, 16));
        packageButton.setForeground(new Color(255,255,255));
        packageButton.setBackground(new Color(0,0,0));
        packageButton.setBounds(400,560,200,40);
        
        //Service Button
        JButton serviceButton = new JButton("See Services");
        serviceButton.setFont(new Font("Arial", 0, 16));
        serviceButton.setForeground(new Color(255,255,255));
        serviceButton.setBackground(new Color(0,0,0));
        serviceButton.setBounds(725,560,200,40);
        
        //Update Button
        JButton updateButton = new JButton("Update");
        updateButton.setFont(new Font("Arial", 0, 16));
        updateButton.setForeground(new Color(255,255,255));
        updateButton.setBackground(new Color(0,0,0));
        updateButton.setBounds(650,430,150,30);
        
        //Confirm Button
        JButton confirmButton = new JButton("Confirm Booking");
        confirmButton.setFont(new Font("Arial", 0, 16));
        confirmButton.setForeground(new Color(255,255,255));
        confirmButton.setBackground(new Color(0,0,0));
        confirmButton.setBounds(650,470,150,30);
        
        //MenuButton
        JButton menuButton = new JButton("Back to Menu");
        menuButton.setFont(new Font("Arial", 0, 14));
        menuButton.setForeground(new Color(255,255,255));
        menuButton.setBackground(new Color(0,0,0));
        menuButton.setBounds(425,630,150,25);
        
         //Credits part
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(650,555,500,350);
    
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        //Added items in Panel
        add(banner);
        add(pictureLogo);
        add(philLogo);
        add(logoText);
        add(location);
        add(instructLabel);
        add(nameLabel);
        add(breakdownLabel);
        add(nameTextField);
        add(contactNumLabel);
        add(contactNumTextField);
        add(venueNameLabel);
        add(venueNameTextField);
        add(packageNameLabel);
        add(packageNameTextField);
        add(serviceNameLabel);
        add(serviceNameTextField);
        add(guestsLabel);
        add(guestsTextField);
        add(priceLabel);
        add(priceTextField);
        add(venuePriceLabel);
        add(packagePriceLabel);
        add(servicePriceLabel);
        add(venueButton);
        add(packageButton);
        add(serviceButton);
        add(updateButton);
        add(confirmButton);
        add(menuButton);
        add(membersName);
        add(socMedPics);
        add(backgroundBelow);
       
       //Events
       //action listeners for the different buttons
       updateButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                updateButtonActionPerformed(e);
       }
       });
       
       venueButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                venueButtonActionPerformed(e);
       }
       });
       
       packageButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                packageButtonActionPerformed(e);
       }
       });
       
       serviceButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                serviceButtonActionPerformed(e);
       }
       });
       
       confirmButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                confirmButtonActionPerformed(e);
       }
       });
       
       menuButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                menuButtonActionPerformed(e);
       }
       });
    }
    
    private void updateButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        
        //updates information of packageNameTextField
        packageInfo = packageWindow.packageInfo;
        packages.setPackageName(packageInfo);
        packageNameTextField.setText(packages.getPackageName());
        
        //updates information of name instance variable
        this.name = nameTextField.getText();
        
        //updates information of contactNum instance variable
        this.contactNum = contactNumTextField.getText();
        
        //updates information of venueNameTextField
        VenueInfo = venueWindow.clickVenueInfo;
        event.setVenueName(VenueInfo);
        venueNameTextField.setText(event.getVenueName());
        
        //updates information of serviceNameTextField
        serviceInfo = serviceWindow.serviceInfo;
        event.setServiceName(serviceInfo);
        serviceNameTextField.setText(event.getServiceName());
        
        //updates information of guestsTextField
        pax = venueWindow.pax;
        event.setGuests(pax);
        guestsTextField.setText(String.valueOf(event.getGuests()));
        
        //updates prices in the breakdown of fees
        price = venueWindow.price;
        venuePriceLabel.setText("Venue Fee: " + String.valueOf(price));
        packagePrice = packageWindow.packagePrice;
        packagePriceLabel.setText("Package Fee: " + String.valueOf(packagePrice));
        servicePrice = serviceWindow.servicePrice;
        servicePriceLabel.setText("Service Fee: " + String.valueOf(servicePrice));
        
        //updates information of priceTextField
        this.totalPrice = price + packagePrice + servicePrice;
        event.setPrice(totalPrice);
        priceTextField.setText(String.valueOf(event.getPrice()));
        
        //Shows message dialog
        JOptionPane.showMessageDialog(f,"Information Updated.");
        
    }
    
    //Shows the venueWindow when venueButton is pressed
    private void venueButtonActionPerformed(ActionEvent e){
        new venueWindow().show();
        this.dispose();
    }
    
    //Shows the packageWindow when packageButton is pressed
    private void packageButtonActionPerformed(ActionEvent e){
        new packageWindow().show();
        this.dispose();
    }
    
    //Shows the serviceWindow when serviceButton is pressed
    private void serviceButtonActionPerformed(ActionEvent e){
        new serviceWindow().show();
        this.dispose();
    }
    
    private void menuButtonActionPerformed(ActionEvent e){
        new Menu().show();
        this.dispose();
    }
    
    private void confirmButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        String name = nameTextField.getText();
        String contactNum = contactNumTextField.getText();
        String venueName = venueNameTextField.getText();
        
        if(name.equals("") || contactNum.equals("") || venueName.equals(""))
            JOptionPane.showMessageDialog(f, "Please fill in missing Information.");
        else
        {
            int input = JOptionPane.showConfirmDialog(f, "Are you sure that you want to Confirm your booking?",
            "Confirm Booking", JOptionPane.YES_NO_OPTION);
            
            if(input == 0){
                this.dispose();
                new confirmWindow().show();
            
                bookWindow.contactNum = "";
                
                //gets variables from venueWindow
                venueWindow.clickVenueInfo = "";
                venueWindow.price = 0;
                venueWindow.pax = 0;
                packageWindow.packageInfo = "N/A";
                packageWindow.packagePrice = 0;
                serviceWindow.serviceInfo = "N/A";
                serviceWindow.servicePrice = 0;
        }
            
        }
        
    }
    public static void main(String[] args){
        new bookWindow().show();
    }
}

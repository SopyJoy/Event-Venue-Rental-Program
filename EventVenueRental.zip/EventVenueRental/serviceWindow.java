import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class serviceWindow extends JFrame
{
    public static String serviceInfo = "N/A";
    public static int servicePrice;
   
    public serviceWindow()
    {
        //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-220,-155,500,350);//x=columns y=rows width, height
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(700,-155,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(780,-155,700,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(50,-155,500,350);
        
        //banner
        ImageIcon imageB = new ImageIcon(getClass().getResource("Services Banner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(-5,-275,1005,800);
        
        //text after the banner
        JLabel text1 = new JLabel("A Full Service Experience");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(350,200,800,100);
        
        //text after text1
        JLabel text2 = new JLabel("We strive to be the unanimous & desired provider of event equipment " 
        +"& event service within the communities we call home");
        text2.setFont(new Font("Arial", 0, 13));
        text2.setForeground(new Color(0, 0,0));
        text2.setBounds(180,255,1000,50);
        
        //pictures of event we will offer
        ImageIcon imageService = new ImageIcon(getClass().getResource("Services Pics.png"));
        JLabel pictureService = new JLabel(imageService);
        pictureService.setBounds(-5,50,1000,800);
        
        //chairsTents Text
        JLabel chairsTents = new JLabel("Chairs & Tents Price 1500");
        chairsTents.setFont(new Font("Arial", 0, 18));
        chairsTents.setForeground(new Color(0, 0,0));
        chairsTents.setBounds(60,570,300,50);
        
        //chairsTents Button
        JButton chairsTentsButton = new JButton("Get Service");
        chairsTentsButton.setFont(new Font("Arial", 1, 16));
        chairsTentsButton.setForeground(new Color(255,255,255));
        chairsTentsButton.setBackground(new Color(0,0,0));
        chairsTentsButton.setBounds(65,610,200,30);
        
        //soundsystem Text
        JLabel soundSystem = new JLabel("Sound System Price 3000");
        soundSystem.setFont(new Font("Arial", 0, 18));
        soundSystem.setForeground(new Color(0, 0,0));
        soundSystem.setBounds(395,570,300,50);
        
        //soundsystem Button
        JButton soundButton = new JButton("Get Service");
        soundButton.setFont(new Font("Arial", 1, 16));
        soundButton.setForeground(new Color(255,255,255));
        soundButton.setBackground(new Color(0,0,0));
        soundButton.setBounds(400,610,200,30);
        
        //catering Text
        JLabel catering = new JLabel("Catering Price 5000");
        catering.setFont(new Font("Arial", 0, 18));
        catering.setForeground(new Color(0, 0,0));
        catering.setBounds(750,570,300,50);
        
        //catering Button
        JButton cateringButton = new JButton("Get Service");
        cateringButton.setFont(new Font("Arial", 1, 16));
        cateringButton.setForeground(new Color(255,255,255));
        cateringButton.setBackground(new Color(0,0,0));
        cateringButton.setBounds(725,610,200,30);
        
        //back to menu
        JButton menu = new JButton("Back to Menu");
        menu.setFont(new Font("Arial", 0, 14));
        menu.setForeground(new Color(255,255,255));
        menu.setBackground(new Color(0,0,0));
        menu.setBounds(425,655,150,25);
        
        //Credits part
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(650,555,500,350);
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        //Added items in Panel
        add(banner);
        add(pictureLogo);
        add(philLogo);
        add(logoText);
        add(location);
        add(text1);
        add(text2);
        add(pictureService);
        add(chairsTents);
        add(chairsTentsButton);
        add(soundSystem);
        add(soundButton);
        add(catering);
        add(cateringButton);
        add(menu);
        add(membersName);
        add(socMedPics);
        add(backgroundBelow);
        
        //Events
       chairsTentsButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               chairsTentsButtonActionPerformed(e);
       }
       });
       
       soundButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               soundButtonActionPerformed(e);
       }
       });
       
       cateringButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               cateringButtonActionPerformed(e);
       }
       });
       menu.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               menu(e);
           }
       });
    }
    
    public void menu(ActionEvent e){
        new Menu().show();
        this.dispose();
    }

    private void chairsTentsButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        //updates the public variable serviceInfo and servicePrice
        this.serviceInfo = "Chairs & Tents Service";
        this.servicePrice = 1500;
        JOptionPane.showMessageDialog(f, "Chairs & Tents Service Selected!\nPress Update to see changes.");
        this.dispose();
        new bookWindow().show();
    }
    
    private void soundButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        //updates the public variable serviceInfo and servicePrice
        this.serviceInfo = "Sound System Service";
        this.servicePrice = 3000;
        JOptionPane.showMessageDialog(f, "Sound System Service Selected!\nPress Update to see changes.");
        this.dispose();
        new bookWindow().show();
    }
    
    private void cateringButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        //updates the public variable serviceInfo and servicePrice
        this.serviceInfo = "Catering Service";
        this.servicePrice = 5000;
        JOptionPane.showMessageDialog(f, "Catering Service Selected!\nPress Update to see changes.");
        this.dispose();
        new bookWindow().show();
    }
    public static void main(String[] args){
        new serviceWindow().show();
    }
}

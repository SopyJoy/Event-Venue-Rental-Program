import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class venueWindow extends JFrame
{
    public static String clickVenueInfo;
    public static int price;
    public static int pax;
    
    //Creates Elements for the JFrame
    String city[] = {"Pampanga", "Manila", "Laguna"};
    
    public venueWindow()
    {
        //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-220,-155,500,350);//x=columns y=rows width, height
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(700,-155,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(780,-155,700,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(50,-155,500,350);
        
        //banner
        ImageIcon imageB = new ImageIcon(getClass().getResource("Event Venue Banner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(0,-210,1000,800);
        
         //combo Box
        JComboBox choice = new JComboBox(city);
        choice.setFont(new Font("Arial",1,16));
        choice.setForeground(new Color(255,255,255));
        choice.setBackground(new Color(0,0,0));
        choice.setBounds(300,270,260,40);
        
        //Search Button
        JButton select = new JButton("Search");
        select.setFont(new Font("Arial", 1, 16));
        select.setForeground(new Color(255,255,255));
        select.setBackground(new Color(0,0,0));
        select.setBounds(570,270,100,40);
    
        //text after the banner
        JLabel text1 = new JLabel("Your next party event venue");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(330,320,800,100);
        
        //text after text1
        JLabel text2 = new JLabel("Discover a collection of unique venues, function halls in Philippines "
        + "that you can book to host your special party.");
        text2.setFont(new Font("Arial", 0, 13));
        text2.setForeground(new Color(0, 0,0));
        text2.setBounds(175,373,1000,50);
        
        //pictures of venues we will offer
        ImageIcon imagePackage = new ImageIcon(getClass().getResource("Event Venue Picture.png"));
        JLabel picturePackage = new JLabel(imagePackage);
        picturePackage.setBounds(-5,135,1000,800);
        
        //back to menu
        JButton menu = new JButton("Back to Menu");
        menu.setFont(new Font("Arial", 0, 14));
        menu.setForeground(new Color(255,255,255));
        menu.setBackground(new Color(0,0,0));
        menu.setBounds(422,665,150,25);
        
        //Credits part
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(650,555,500,350);
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
       
        //Add to Panel
        add(pictureLogo);
        add(logoText);
        add(location);
        add(philLogo);
        add(text1);
        add(text2);
        add(membersName);
        add(socMedPics);
        add(picturePackage);
        add(backgroundBelow);
        add(menu);
        add(select);
        add(choice);
        add(banner);
        
       //Events
       //Calling the method after selecting the city
       select.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               String getCity = (String) choice.getSelectedItem();
           if (getCity.equals("Pampanga")){
               new pampangaVenue().show();
           }
           else if (getCity.equals("Manila")){
               new manilaVenue().show();
           }
           else if (getCity.equals("Laguna")){
               new lagunaVenue().show();
           }
           setVisible(false);
           }
       });
       
        menu.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               menu(e);
           }
       });
    }
    
    public void menu(ActionEvent e){
        new Menu().show();
        this.dispose();
    }
    public static void main(String[] args){
        new venueWindow().show();
        
    }
}
    

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
//Class for Manila Venues
public class manilaVenue extends JFrame{
  
    public manilaVenue(){
        
        //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-220,-158,500,350);//x=columns y=rows width, height
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(700,-155,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(780,-155,700,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(50,-155,500,350);
        
        //banner
        ImageIcon imageB = new ImageIcon(getClass().getResource("Manila Banner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(-5,-275,1005,800);
        
        //text after the banner
        JLabel text1 = new JLabel("Experience the Unique Venues");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(325,200,800,100);
        
        //text after text1
        JLabel text2 = new JLabel("Looking for event venues or event spaces for rent in The Philippines?" 
        +" Find the perfect events place in Manila");
        text2.setFont(new Font("Arial", 0, 13));
        text2.setForeground(new Color(0, 0,0));
        text2.setBounds(200,255,1000,50);
        
        //pictures of event we will offer
        ImageIcon imageService = new ImageIcon(getClass().getResource("Manila Venues 1.png"));
        JLabel pictureService = new JLabel(imageService);
        pictureService.setBounds(-5,50,1000,800);
        
        //Palacio de Maynila Text
        JLabel venueTitle = new JLabel("Palacio de Maynila");
        venueTitle.setFont(new Font("Arial", 1, 18));
        venueTitle.setForeground(new Color(0, 0,0));
        venueTitle.setBounds(83,535,300,50);
        
        //Palacio de Maynila Price and Pax
        JLabel priceAndPack = new JLabel("Price: 13000 Pax: 250");
        priceAndPack.setFont(new Font("Arial", 0, 15));
        priceAndPack.setForeground(new Color(0, 0,0));
        priceAndPack.setBounds(90,555,300,50);
        
        //Palacio de Maynila Location
        JLabel venueInfo = new JLabel("1809-1813 M.H Del Pilar Malate,NCR");
        venueInfo.setFont(new Font("Arial", 0, 15));
        venueInfo.setForeground(new Color(0, 0,0));
        venueInfo.setBounds(45,575,300,50);
        
        //Palacio de Maynila Button
        JButton selectVenue = new JButton("Get Venue");
        selectVenue.setFont(new Font("Arial", 1, 16));
        selectVenue.setForeground(new Color(255,255,255));
        selectVenue.setBackground(new Color(0,0,0));
        selectVenue.setBounds(65,620,200,30);
        
        //Puerta Real Garden Text
        JLabel venueTitle1 = new JLabel("Puerta Real Garden");
        venueTitle1.setFont(new Font("Arial", 1, 18));
        venueTitle1.setForeground(new Color(0, 0,0));
        venueTitle1.setBounds(415,535,300,50);
        
        //Puerta Real Garden Price and Pack
        JLabel priceAndPack1 = new JLabel("Price: 12300 Pax: 1000");
        priceAndPack1.setFont(new Font("Arial", 0, 15));
        priceAndPack1.setForeground(new Color(0, 0,0));
        priceAndPack1.setBounds(425,555,300,50);
        
        //Puerta Real Garden Location
        JLabel venueInfo1 = new JLabel("General Luna St.,Manila");
        venueInfo1.setFont(new Font("Arial", 0, 15));
        venueInfo1.setForeground(new Color(0, 0,0));
        venueInfo1.setBounds(425,575,300,50);
        
        //Puerta Real Garden Button
        JButton selectVenue1 = new JButton("Get Venue");
        selectVenue1.setFont(new Font("Arial", 1, 16));
        selectVenue1.setForeground(new Color(255,255,255));
        selectVenue1.setBackground(new Color(0,0,0));
        selectVenue1.setBounds(400,620,200,30);
        
         //SMX Convention Center Text
        JLabel venueTitle2 = new JLabel("SMX Convention Center");
        venueTitle2.setFont(new Font("Arial", 1, 18));
        venueTitle2.setForeground(new Color(0, 0,0));
        venueTitle2.setBounds(720,535,300,50);
        
        //SMX Convention Center Price and Pack
        JLabel priceAndPack2 = new JLabel("Price: 12000 Pax: 120");
        priceAndPack2.setFont(new Font("Arial", 0, 15));
        priceAndPack2.setForeground(new Color(0, 0,0));
        priceAndPack2.setBounds(750,555,300,50);
        
        //SMX Convention Center Location
        JLabel venueInfo2 = new JLabel("Mall of Asia Complex,Pasay,Manila");
        venueInfo2.setFont(new Font("Arial", 0, 15));
        venueInfo2.setForeground(new Color(0, 0,0));
        venueInfo2.setBounds(700,575,300,50);
        
        //SMX Convention Center Button
        JButton selectVenue2 = new JButton("Get Venue");
        selectVenue2.setFont(new Font("Arial", 1, 16));
        selectVenue2.setForeground(new Color(255,255,255));
        selectVenue2.setBackground(new Color(0,0,0));
        selectVenue2.setBounds(725,620,200,30);
        
        // Back to Menu
        JButton menu = new JButton("Back to Menu");
        menu.setFont(new Font("Arial", 0, 14));
        menu.setForeground(new Color(255,255,255));
        menu.setBackground(new Color(0,0,0));
        menu.setBounds(330,665,150,20);
        
        //back to Venue
        JButton venue = new JButton("Back to Venue");
        venue.setFont(new Font("Arial", 0, 14));
        venue.setForeground(new Color(255,255,255));
        venue.setBackground(new Color(0,0,0));
        venue.setBounds(520,665,150,20);
      
        //Credits part
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(650,555,500,350);
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        //Added to Panel
        add(banner);
        add(pictureLogo);
        add(philLogo);
        add(logoText);
        add(location);
        add(text1);
        add(text2);
        add(pictureService);
        
        //Venue 1
        add(venueTitle);
        add(priceAndPack);
        add(venueInfo);
        add(selectVenue);
        //Venue 2
        add(venueTitle1);
        add(priceAndPack1);
        add(venueInfo1);
        add(selectVenue1);
        //Venue 3
        add(venueTitle2);
        add(priceAndPack2);
        add(venueInfo2);
        add(selectVenue2);
        
        add(menu);
        add(venue);
        add(membersName);
        add(socMedPics);
        add(backgroundBelow);
        
         //Events
        //Venue 1
       selectVenue.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               selectedVenue1(e);
           }
       });
       //Venue 2
       selectVenue1.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               selectedVenue2(e);
           }
       });
       //Venue 3
       selectVenue2.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               selectedVenue3(e);
           }
       });
       //menu
       menu.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               menu(e);
           }
       });
       //venue
       venue.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               venue(e);
           }
       });
       
    }
    
    public void venue(ActionEvent e){
        new venueWindow().show();
        this.dispose();
    }
    public void menu(ActionEvent e){
        new Menu().show();
        this.dispose();
    }
    public void selectedVenue1(ActionEvent e){
        venueWindow.clickVenueInfo = "Palacio De Maynila";
        venueWindow.price = 13000;
        venueWindow.pax = 250;
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "You have chosen this venue. Check the Booking Tab to see details");
        new bookWindow().show();
        this.dispose();
    }
    public void selectedVenue2(ActionEvent e){
        venueWindow.clickVenueInfo = "Puerta Real Garden";
        venueWindow.price = 12300;
        venueWindow.pax = 1000;
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "You have chosen this venue. Check the Booking Tab to see details");
        new bookWindow().show();
        this.dispose();
    }
    public void selectedVenue3(ActionEvent e){
        venueWindow.clickVenueInfo = "SMX Convention Center";
        venueWindow.price = 20000;
        venueWindow.pax = 2500;
        JFrame f = new JFrame();
        JOptionPane.showMessageDialog(f, "You have chosen this venue. Check the Booking Tab to see details");
        new bookWindow().show();
        this.dispose();
    }
    
    public static void main(String[] args){
        new manilaVenue().show();
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class confirmWindow extends JFrame
{
    
    public confirmWindow()
    {
       //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-230,-160,500,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(40,-160,500,350);
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(210,-160,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(290,-160,500,350);
        
        //Booked Text
        JLabel menuText = new JLabel("Your Event has been Booked");
        menuText.setFont(new Font("Arial", 1, 30));
        menuText.setForeground(new Color(0,0,0));
        menuText.setBounds(33,-90,500,300);
        
        //name text
        String name = bookWindow.name;
        JLabel nameText = new JLabel(name);
        nameText.setFont(new Font("Arial", 0, 16));
        nameText.setForeground(new Color(0,0,0));
        nameText.setBounds(160,-60,500,300);
        bookWindow.name = "";
        
        //Thank you Text
        JLabel textLabel = new JLabel("Thank you for using our service.");
        textLabel.setFont(new Font("Arial", 0, 16));
        textLabel.setForeground(new Color(0,0,0));
        textLabel.setBounds(120,-35,500,300);
        
        //After thank you text
        JLabel textLabel1 = new JLabel("You can press Menu to book another event.");
        textLabel1.setFont(new Font("Arial", 0, 16));
        textLabel1.setForeground(new Color(0,0,0));
        textLabel1.setBounds(100,-15,500,300);
        
        //Menu Button
        JButton backButton = new JButton("MENU");
        backButton.setFont(new Font("Arial", 1, 16));
        backButton.setForeground(new Color(255,255,255));
        backButton.setBackground(new Color(0,0,0));
        backButton.setBounds(150,180,200,50);
        
        //Exit Button
        JButton exitButton = new JButton("EXIT");
        exitButton.setFont(new Font("Arial", 1, 16));
        exitButton.setForeground(new Color(255,255,255));
        exitButton.setBackground(new Color(0,0,0));
        exitButton.setBounds(150,250,200,50);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(10,328,500,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(165,180,500,350);
    
        //Credits background below
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,335,500,40);
       
       //background
        ImageIcon imageB = new ImageIcon(getClass().getResource("Menu Background.png"));
        JLabel background = new JLabel(imageB);
        background.setBounds(0,150,500,350);
       
       //frame
        setTitle("Confirm Booking");
        setSize(500,410);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        //Add to Panel
        add(pictureLogo);
        add(logoText);
        add(philLogo);
        add(location);
        add(menuText);
        add(nameText);
        add(textLabel);
        add(textLabel1);
        add(backButton);
        add(exitButton);
        add(membersName);
        add(socMedPics);
        add(backgroundBelow);
        add(background);
        
        //Events
         backButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               backButtonActionPerformed(e);
       }
       });
       
       exitButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               exitButtonActionPerformed(e);
       }
       });
       
    }
    
    private void backButtonActionPerformed(ActionEvent e){
        this.dispose();
        new Menu().show();
    }

    private void exitButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you for using this Application!");
        System.exit(0);    
    }
    
    public static void main(String[] args){
        new confirmWindow().show();
    }
    
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class packageWindow extends JFrame
{
    public static String packageInfo = "N/A";
    public static int packagePrice;
    
    //creates Packages Object
    Packages packages = new Packages();
    
    public packageWindow()
    {
        //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-220,-155,500,350);//x=columns y=rows width, height
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(700,-155,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(780,-155,700,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(50,-155,500,350);
        
        //banner
        ImageIcon imageB = new ImageIcon(getClass().getResource("Package Banner.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(-5,-275,1005,800);
        
        //text after the banner
        JLabel text1 = new JLabel("Events Without The Guess Work");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(320,200,800,100);
        
        //text after text1
        JLabel text2 = new JLabel("Save time & energy with our curated table-setting packages, "
        + "enjoy your event without the hassle");
        text2.setFont(new Font("Arial", 0, 13));
        text2.setForeground(new Color(0, 0,0));
        text2.setBounds(230,255,1000,50);
        
        //pictures of event we will offer
        ImageIcon imageService = new ImageIcon(getClass().getResource("Pictures of Packages.png"));
        JLabel pictureService = new JLabel(imageService);
        pictureService.setBounds(-5,50,1000,800);
        
        //birthday Text
        JLabel bdayPackLabel = new JLabel("Birthdays Set Price 4999");
        bdayPackLabel.setFont(new Font("Arial", 0, 18));
        bdayPackLabel.setForeground(new Color(0, 0,0));
        bdayPackLabel.setBounds(66,570,300,50);
        
        //birthday Button
        JButton bdayPackButton = new JButton("Get Package");
        bdayPackButton.setFont(new Font("Arial", 1, 16));
        bdayPackButton.setForeground(new Color(255,255,255));
        bdayPackButton.setBackground(new Color(0,0,0));
        bdayPackButton.setBounds(65,610,200,30);
        
        //seminar Text
        JLabel seminarPackLabel = new JLabel("Meetings Set Price 2999");
        seminarPackLabel.setFont(new Font("Arial", 0, 18));
        seminarPackLabel.setForeground(new Color(0, 0,0));
        seminarPackLabel.setBounds(400,570,200,50);
        
        //seminar Button
        JButton seminarPackButton = new JButton("Get Package");
        seminarPackButton.setFont(new Font("Arial", 1, 16));
        seminarPackButton.setForeground(new Color(255,255,255));
        seminarPackButton.setBackground(new Color(0,0,0));
        seminarPackButton.setBounds(400,610,200,30);
        
        //wedding Text
        JLabel weddingPackLabel = new JLabel("Weddings Set Price 6999");
        weddingPackLabel.setFont(new Font("Arial", 0, 18));
        weddingPackLabel.setForeground(new Color(0, 0,0));
        weddingPackLabel.setBounds(720,570,300,50);
        
        //wedding Button
        JButton weddingPackButton = new JButton("Get Package");
        weddingPackButton.setFont(new Font("Arial", 1, 16));
        weddingPackButton.setForeground(new Color(255,255,255));
        weddingPackButton.setBackground(new Color(0,0,0));
        weddingPackButton.setBounds(725,610,200,30);
        
        //back to menu
        JButton menu = new JButton("Back to Menu");
        menu.setFont(new Font("Arial", 0, 14));
        menu.setForeground(new Color(255,255,255));
        menu.setBackground(new Color(0,0,0));
        menu.setBounds(425,655,150,25);
        
         //Credits part
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(650,555,500,350);
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        
        //Added items in Panel
        add(banner);
        add(pictureLogo);
        add(philLogo);
        add(logoText);
        add(location);
        add(text1);
        add(text2);
        add(pictureService);
        add(bdayPackLabel);
        add(bdayPackButton);
        add(seminarPackLabel);
        add(seminarPackButton);
        add(weddingPackLabel);
        add(weddingPackButton);
        add(menu);
        add(membersName);
        add(socMedPics);
        add(backgroundBelow);
        
        //Events
       bdayPackButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               bdayPackButtonActionPerformed(e);
       }
       });
       
       seminarPackButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               seminarPackButtonActionPerformed(e);
       }
       });
       
       weddingPackButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               weddingPackButtonActionPerformed(e);
       }
       });
        menu.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               menu(e);
           }
       });
    }
    
    public void menu(ActionEvent e){
        new Menu().show();
        this.dispose();
    }

    private void bdayPackButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        //updates the public variable packageInfo and packagePrice
        this.packageInfo = "Birthday Package";
        this.packagePrice = packages.getBdayPackPrice();
        JOptionPane.showMessageDialog(f, "Birthday Package Selected!\nPress Update to see changes.");
        this.dispose();
        new bookWindow().show();
        
    }
    
    private void weddingPackButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        //updates the public variable packageInfo and packagePrice
        this.packageInfo = "Wedding Package";
        this.packagePrice = packages.getWedPackPrice();
        JOptionPane.showMessageDialog(f, "Wedding Package Selected!\nPress Update to see changes.");
        this.dispose();
        new bookWindow().show();
        
    }
    
    private void seminarPackButtonActionPerformed(ActionEvent e){
        JFrame f = new JFrame();
        //updates the public variable packageInfo and packagePrice
        this.packageInfo = "Meeting Package";
        this.packagePrice = packages.getSemPackPrice();
        JOptionPane.showMessageDialog(f, "Meeting Package Selected!\nPress Update to see changes.");
        this.dispose();
        new bookWindow().show();
        
    }
    
    public static void main(String[] args) {
        new packageWindow().show();
    }  
}

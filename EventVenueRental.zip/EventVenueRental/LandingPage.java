import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;

public class LandingPage extends JFrame
{
      
    public LandingPage()
    {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
            exitForm(e);
        }
        });  
        
        //picture logo
        ImageIcon image = new ImageIcon(getClass().getResource("Eventrifying Logo 1.png"));
        JLabel pictureLogo = new JLabel(image);
        pictureLogo.setBounds(-220,-155,500,350);//x=columns y=rows width, height
        
        //philippines logo
        ImageIcon imageP = new ImageIcon(getClass().getResource("Philippine Logo 1.png"));
        JLabel philLogo = new JLabel(imageP);
        philLogo.setBounds(700,-155,500,350);
        
        //location
        JLabel location = new JLabel("Located only in Philippines");
        location.setFont(new Font("Arial", 0, 13));
        location.setForeground(new Color(0,0,0));
        location.setBounds(780,-155,700,350);
        
        //logo text
        JLabel logoText = new JLabel("EVENTRIFYING");
        logoText.setFont(new Font("Arial", 0, 13));
        logoText.setForeground(new Color(0,0,0));
        logoText.setBounds(50,-155,500,350);
        
        //banner
        ImageIcon imageB = new ImageIcon(getClass().getResource("Welcome Page Banner 1.png"));
        JLabel banner = new JLabel(imageB);
        banner.setBounds(0,-210,1000,800);
        
        //Button
        JButton startButton = new JButton("START BOOKING!");
        startButton.setFont(new Font("Arial", 1, 16));
        startButton.setForeground(new Color(255,255,255));
        startButton.setBackground(new Color(0,0,0));
        startButton.setBounds(350,270,300,40);
        
        //text after the banner
        JLabel text1 = new JLabel("Awesome Event Venues for Rental in Philippines");
        text1.setFont(new Font("Arial", 1, 25));
        text1.setForeground(new Color(0,0,0));
        text1.setBounds(200,330,800,100);
        
        //text after text1
        JLabel text2 = new JLabel("Are you planning for a fun and exciting party" 
        + " and are in need of a unique space to WOW your guests? Eventrifying will help you.");
        text2.setFont(new Font("Arial", 0, 13));
        text2.setForeground(new Color(0, 0,0));
        text2.setBounds(115,385,1000,50);
         
        //pictures of event we will offer
        ImageIcon imagePackage = new ImageIcon(getClass().getResource("Pictures of Packages.png"));
        JLabel picturePackage = new JLabel(imagePackage);
        picturePackage.setBounds(-5,150,1000,800);
        
        //Credits part
        JPanel backgroundBelow = new JPanel();
        backgroundBelow.setBackground(new Color(204,204,204));
        backgroundBelow.setBounds(0,700,1000,70);
        
        //Credits Text
        JLabel membersName = new JLabel("Created by: Patrick Gomez | Jann Visperas | Sofia Yunun");
        membersName.setFont(new Font("Arial", 0, 13));
        membersName.setForeground(new Color(102,102,102));
        membersName.setBounds(20,705,1000,50);
        
        //social media logo
        ImageIcon imageSocial = new ImageIcon(getClass().getResource("Socia Media Logo.png"));
        JLabel socMedPics = new JLabel(imageSocial);
        socMedPics.setBounds(650,555,500,350);
    
        
        //frame
        setTitle("EVENTRIFYING");
        setSize(1000,800);
        setLayout(null);
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        //Added to the Pane
        add(startButton);
        add(membersName);
        add(text1);
        add(text2);
        add(logoText);
        add(location);
        add(philLogo);
        add(pictureLogo);
        add(socMedPics);
        add(picturePackage);
        add(backgroundBelow);
        add(banner);
        
        //Event
        startButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            startButtonActionPerformed(e);
        }
        });
    }
    
    private void exitForm(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you for using this Application");
        
    }
    
    private void startButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        new Menu().show();
        setVisible(false);
        
    }
    
    public static void main(String[] args){
        new LandingPage().show();
    }

}

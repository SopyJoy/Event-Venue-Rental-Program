
public class Packages extends Events
{
    public String packageName; 
    public int bdayPackPrice, wedPackPrice, semPackPrice;
    
    public Packages(){}
    
    public void setPackageName(String packageName)
    {
        this.packageName = packageName;    
    }
    
    public String getPackageName()
    {
        return packageName;        
    }
    
    public int getBdayPackPrice()
    {
        bdayPackPrice = 4999;
        return bdayPackPrice;        
    }
    
    public int getWedPackPrice()
    {
        wedPackPrice = 6999;
        return wedPackPrice;        
    }
    
    public int getSemPackPrice()
    {
        semPackPrice = 2999;
        return semPackPrice;        
    }
}
